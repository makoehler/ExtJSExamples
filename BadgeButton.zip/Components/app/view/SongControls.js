Ext.define('Pandora.view.SongControls', {
    extend: 'Ext.Container',
    alias: 'widget.songcontrols',
    height: 70,
	requires : ['Pandora.view.BadgeButton'],
    
    initComponent: function() {
        this.layout = {
            type: 'vbox',
            align: 'center',
            pack: 'center'
        };
        
        this.items = [{
            xtype: 'container',
            defaultType: 'button',
            height: 30,
            width: 300,
            layout: {
                type: 'hbox',
                align: 'center',
                pack: 'center'
            },
            items: [{
                text: 'Vote Down',
                action: 'vote-down'
            }, {
                text: 'Vote Up',
                action: 'vote-up',
				xtype : 'badgebutton',
				badgeText : '1',
				handler : function() {
					var badgeTextVal = this.badgeText;
					if ( Ext.isEmpty( badgeTextVal ) ) {
						badgeTextVal = 0;
					}
					badgeTextVal = parseInt(badgeTextVal) + 1;
					this.setBadgeText( badgeTextVal );
				}
            }, {
                text: 'Pause',
                action: 'pause'
            }, {
                text: 'Skip',
                action: 'skip'
            }]
        }];
        
        this.callParent();
    }
});