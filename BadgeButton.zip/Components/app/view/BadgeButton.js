Ext.define('Pandora.view.BadgeButton',{
	extend:'Ext.button.Button',
	alias:'widget.badgebutton',
	
	config:{
		badgeText:null, 
		renderTpl: [
		            '<em id="{id}-btnWrap"<tpl if="splitCls"> class="{splitCls}"</tpl>>',
		                '<tpl>',
		                    '<button id="{id}-btnEl" type="{type}" class="{btnCls}" hidefocus="true"',
		                        '<tpl if="tabIndex"> tabIndex="{tabIndex}"</tpl>',
		                        '<tpl if="disabled"> disabled="disabled"</tpl>',
		                      ' role="button" autocomplete="off">',
		                      '<tpl if="badgeText"> <span id="{id}-btnbadge" class="{baseCls}-badgeCls" reference= "badgeElement",> {badgeText}</span></tpl>',
		                      '<span id="{id}-btnIconEl" class="{baseCls}-icon {iconCls}"<tpl if="iconUrl"> style="background-image:url({iconUrl})"</tpl>></span>',
		                      '<span id="{id}-btnInnerEl" class="{baseCls}-inner" style="{innerSpanStyle}">',
	                            '{text}',
	                          '</span>',
		                    '</button>',
		                '</tpl>',
		            '</em>',
		            '<tpl if="closable">',
		                '<a id="{id}-closeEl" href="#" class="{baseCls}-close-btn" title="{closeText}"></a>',
		            '</tpl>'
		        ]
},
childEls:[
	       'btnbadge'
	       ],
	constructor:function( config ){
		var me = this;
		console.log( me.config );
		Ext.apply(this.config,config);
		this.callParent( arguments );
		console.log( me.config );
	},
	
	
	/**
     * This method returns an object which provides substitution parameters for the {@link #renderTpl XTemplate} used to
     * create this Button's DOM structure.
     *
     * Instances or subclasses which use a different Template to create a different DOM structure may need to provide
     * their own implementation of this method.
     *
     * @return {Object} Substitution data for a Template. The default implementation which provides data for the default
     * {@link #template} returns an Object containing the following properties:
     * @return {String} return.type The `<button>`'s {@link #type}
     * @return {String} return.splitCls A CSS class to determine the presence and position of an arrow icon.
     * (`'x-btn-arrow'` or `'x-btn-arrow-bottom'` or `''`)
     * @return {String} return.cls A CSS class name applied to the Button's main `<tbody>` element which determines the
     * button's scale and icon alignment.
     * @return {String} return.text The {@link #text} to display ion the Button.
     * @return {Number} return.tabIndex The tab index within the input flow.
     */
    getTemplateArgs: function() {
        var me = this,
            persistentPadding = me.getPersistentPadding(),
            innerSpanStyle = '';

        // Create negative margin offsets to counteract persistent button padding if needed
        if (Math.max.apply(Math, persistentPadding) > 0) {
            innerSpanStyle = 'margin:' + Ext.Array.map(persistentPadding, function(pad) {
                return -pad + 'px';
            }).join(' ');
        }

        return {
            href     : me.getHref(),
            disabled : me.disabled,
            hrefTarget: me.hrefTarget,
            type     : me.type,
            btnCls   : me.getBtnCls() +' has-badge',
            splitCls : me.getSplitCls(),
            iconUrl  : me.icon,
            iconCls  : me.iconCls,
            text     : me.text || '&#160;',
            badgeText:me.badgeText ||  undefined,
            tabIndex : me.tabIndex,
            innerSpanStyle: innerSpanStyle
        };
    },

    	
setBadgeText:function(text) {
            var me = this;
            if( Ext.isEmpty( text)){
            	text  = undefined;
            	me.btnbadge.addCls('hide-badge');
            	}else{
            	me.btnbadge.removeCls('hide-badge');
            	}
            me.badgeText = text;
            if (me.rendered) {
                me.btnbadge.update(text );
            }
            return me;
        }
  
    
	
});
